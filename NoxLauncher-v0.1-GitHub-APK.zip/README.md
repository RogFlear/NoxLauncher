# Nox Launcher

Nox Launcher v0.1 — Android Minecraft launcher foundation.

## Current features
- Premium dark purple/blue UI
- Home screen
- Minecraft version selector UI
- RAM allocation slider
- Versions screen
- Settings screen
- Bottom navigation

## Build
Open this project in Android Studio, let Gradle sync, then run on an Android device/emulator.

The Minecraft runtime and authentication are intentionally not connected yet; those are the next development stages.
