package com.noxlauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090711)
private val Card = Color(0xFF15111F)
private val Purple = Color(0xFF9B5CFF)
private val Blue = Color(0xFF4B8DFF)
private val Muted = Color(0xFFAAA2B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NoxLauncherApp() }
    }
}

@Composable
fun NoxLauncherApp() {
    var tab by remember { mutableStateOf(0) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = Purple
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF17102A), Bg, Color(0xFF080A15))
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(18.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("NOX", color = Color.White, fontSize = 25.sp,
                            fontWeight = FontWeight.ExtraBold)
                        Text("LAUNCHER", color = Purple, fontSize = 11.sp,
                            fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    }
                    Text("⚙", color = Color.White, fontSize = 25.sp,
                        modifier = Modifier.clickable { tab = 2 })
                }

                Spacer(Modifier.height(28.dp))

                when (tab) {
                    0 -> HomeScreen()
                    1 -> VersionsScreen()
                    else -> SettingsScreen()
                }

                Spacer(Modifier.weight(1f))

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    NavItem("⌂", "Home", tab == 0) { tab = 0 }
                    NavItem("▣", "Versions", tab == 1) { tab = 1 }
                    NavItem("⚙", "Settings", tab == 2) { tab = 2 }
                }
            }
        }
    }
}

@Composable
fun HomeScreen() {
    Text("Welcome back,", color = Muted, fontSize = 15.sp)
    Text("NoxZen 👋", color = Color.White, fontSize = 30.sp,
        fontWeight = FontWeight.Bold)

    Spacer(Modifier.height(22.dp))

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("MINECRAFT VERSION", color = Muted, fontSize = 11.sp,
                fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(9.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Minecraft 1.21.11", color = Color.White, fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold)
                Text("▼", color = Purple)
            }
        }
    }

    Spacer(Modifier.height(16.dp))

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("MEMORY", color = Muted, fontSize = 11.sp,
                fontWeight = FontWeight.Bold)
            var ram by remember { mutableFloatStateOf(4f) }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("RAM allocation", color = Color.White, fontSize = 15.sp)
                Text("${ram.toInt()} GB", color = Purple, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = ram,
                onValueChange = { ram = it },
                valueRange = 1f..8f,
                steps = 6,
                colors = SliderDefaults.colors(
                    thumbColor = Purple,
                    activeTrackColor = Purple
                )
            )
        }
    }

    Spacer(Modifier.height(25.dp))

    Button(
        onClick = { },
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Purple)
    ) {
        Text("▶  PLAY", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
    }

    Spacer(Modifier.height(12.dp))
    Text("Minecraft runtime not connected yet", color = Muted,
        fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
}

@Composable
fun VersionsScreen() {
    Text("Versions", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(18.dp))
    VersionCard("Minecraft 1.21.11", "Latest", true)
    VersionCard("Minecraft 1.21.10", "Installed", false)
    Spacer(Modifier.height(15.dp))
    OutlinedButton(
        onClick = { },
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp)
    ) { Text("+  Add version") }
}

@Composable
fun VersionCard(name: String, status: String, selected: Boolean) {
    Surface(
        color = if (selected) Color(0xFF211535) else Card,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
    ) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, color = Color.White, fontWeight = FontWeight.Bold)
                Text(status, color = if (selected) Purple else Muted, fontSize = 12.sp)
            }
            if (selected) Text("✓", color = Purple, fontSize = 20.sp)
        }
    }
}

@Composable
fun SettingsScreen() {
    Text("Settings", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(18.dp))
    SettingRow("Account", "NoxZen")
    SettingRow("Game directory", "NoxLauncher/.minecraft")
    SettingRow("Java runtime", "Not configured")
    SettingRow("Launcher version", "0.1.0")
}

@Composable
fun SettingRow(title: String, value: String) {
    Surface(
        color = Card,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
    ) {
        Column(Modifier.padding(17.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(value, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 25.dp, vertical = 7.dp)
    ) {
        Text(icon, color = if (selected) Purple else Muted, fontSize = 20.sp)
        Text(label, color = if (selected) Color.White else Muted, fontSize = 11.sp)
    }
}
